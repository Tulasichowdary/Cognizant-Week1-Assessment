package com.cognizant.eureka_discovery_slient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaDiscoverySlientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaDiscoverySlientApplication.class, args);
	}

}
