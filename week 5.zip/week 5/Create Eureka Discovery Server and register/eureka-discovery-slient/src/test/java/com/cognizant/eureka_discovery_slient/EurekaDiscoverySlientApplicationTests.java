package com.cognizant.eureka_discovery_slient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoverySlientApplicationTests {

	@Test
	void contextLoads() {
	}

}
