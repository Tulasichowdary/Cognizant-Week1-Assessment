import React from "react";
import ReactDOM from "react-dom";
import OnlineShopping from "./OnlineShopping";

ReactDOM.render(<OnlineShopping />, document.getElementById("root"));
