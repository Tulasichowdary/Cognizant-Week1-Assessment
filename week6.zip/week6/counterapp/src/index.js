import React from "react";
import ReactDOM from "react-dom";
import CountPeople from "./CountPeople";

ReactDOM.render(<CountPeople />, document.getElementById("root"));
