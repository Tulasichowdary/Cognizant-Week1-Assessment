import React from "react";

function Home() {
  return (
    <div>
      <h2>Welcome to TrainersApp</h2>
      <p>This app maintains a list of SPA trainers using React technology.</p>
    </div>
  );
}

export default Home;
