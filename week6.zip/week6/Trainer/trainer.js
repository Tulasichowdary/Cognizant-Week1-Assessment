export class Trainer {
  constructor(trainerId, name, phone, email, stream, skills) {
    this.trainerId = trainerId;
    this.name = name;
    this.phone = phone;
    this.email = email;
    this.stream = stream;
    this.skills = skills;
  }
}
